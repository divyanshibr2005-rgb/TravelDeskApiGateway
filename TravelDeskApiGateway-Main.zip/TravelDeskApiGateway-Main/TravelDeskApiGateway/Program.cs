using Microsoft.AspNetCore.HttpOverrides;
using Ocelot.DependencyInjection;
using Ocelot.Middleware;


var builder = WebApplication.CreateBuilder(args);

// -----------------------------------------------------------
// 1) Logging
// -----------------------------------------------------------
builder.Logging.ClearProviders();
builder.Logging.AddConsole();

// Optional: tune log levels via appsettings.json; set "Ocelot": "Debug" for deep traces


// -----------------------------------------------------------
// 2) Configuration (Ocelot routes)
// -----------------------------------------------------------
// Ensure ocelot.json is copied to output and watches for changes
builder.Configuration.AddJsonFile("ocelot.json", optional: false, reloadOnChange: true);

// -----------------------------------------------------------
// 3) CORS
// -----------------------------------------------------------
// Replace with your real frontend origins when known (examples for React/Vite/Angular dev)
const string CorsPolicyName = "AllowFrontend";
builder.Services.AddCors(options =>
{
    options.AddPolicy(CorsPolicyName, policy =>
    {
        policy
            // In dev you can temporarily allow any origin; for prod, prefer WithOrigins(...)
            .AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod()
            .WithOrigins("http://localhost:4200", "http://localhost:5173")
            .AllowCredentials(); // only if you use cookies + specific origins (not with AllowAnyOrigin)
    });
});

// -----------------------------------------------------------
// 4) Forwarded headers (if running behind reverse proxy later)
// -----------------------------------------------------------
builder.Services.Configure<ForwardedHeadersOptions>(opts =>
{
    opts.ForwardedHeaders =
        ForwardedHeaders.XForwardedFor |
        ForwardedHeaders.XForwardedProto |
        ForwardedHeaders.XForwardedHost;

    // If you know your proxy IPs, set KnownProxies/KnownNetworks for security
    // opts.KnownProxies.Add(IPAddress.Parse("10.0.0.1"));
});

// -----------------------------------------------------------
// 5) Ocelot
// -----------------------------------------------------------
builder.Services.AddOcelot();

// (Optional) Health checks; here we just expose a simple liveness endpoint
builder.Services.AddHealthChecks();

var app = builder.Build();

// -----------------------------------------------------------
// 6) Middleware pipeline order
// -----------------------------------------------------------
if (app.Environment.IsDevelopment())
{
    // In dev you might also expose minimal exception page; for APIs this is often enough
    app.UseDeveloperExceptionPage();
}

app.UseHttpsRedirection();

// If behind a proxy/ingress:
app.UseForwardedHeaders();

// CORS must be before UseOcelot() so OPTIONS and actual requests get headers
app.UseCors(CorsPolicyName);

// (Optional) If you add auth later, place it before Ocelot
// app.UseAuthentication();
// app.UseAuthorization();

// Simple health endpoint (useful for container orchestrators and quick checks)
app.MapGet("/health", () => Results.Ok(new { status = "Healthy", ts = DateTimeOffset.UtcNow }));

// Wire Ocelot into the pipeline (must be awaited)
await app.UseOcelot();

app.Run();

public partial class Program { }
