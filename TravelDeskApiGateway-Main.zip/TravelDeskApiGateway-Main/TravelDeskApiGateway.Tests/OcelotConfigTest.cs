using Microsoft.Extensions.Configuration;
using NUnit.Framework;

namespace TravelDeskApiGateway.Tests
{
    [TestFixture]
    public class OcelotConfigTest
    {
        private IConfiguration _configuration = null!;

        [SetUp]
        public void Setup()
        {
            _configuration = new ConfigurationBuilder()
                .AddJsonFile("ocelot.json", optional: false)
                .Build();
        }

        [Test]
        public void OcelotConfig_ShouldContainUsersRoute()
        {
            var routes = _configuration.GetSection("Routes").GetChildren();

            Assert.That(routes, Is.Not.Empty);

            var hasUsersRoute = routes.Any(r =>
                r["UpstreamPathTemplate"] == "/users");

            Assert.That(hasUsersRoute, Is.True);
        }

        [Test]
        public void OcelotConfig_ShouldContainRequestsRoute()
        {
            var routes = _configuration.GetSection("Routes").GetChildren();

            var hasRequestsRoute = routes.Any(r =>
                r["UpstreamPathTemplate"] == "/requests");

            Assert.That(hasRequestsRoute, Is.True);
        }
    }
}
