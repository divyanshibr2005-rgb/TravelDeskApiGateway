using Microsoft.AspNetCore.Mvc.Testing;
using NUnit.Framework;

namespace TravelDeskApiGateway.Tests
{
    [TestFixture]
    public class AppStartupTests
    {
        [Test]
        public void Application_ShouldStartSuccessfully()
        {
            // Act & Assert
            Assert.DoesNotThrow(() =>
            {
                var factory = new WebApplicationFactory<Program>();
                var client = factory.CreateClient();
            });
        }
    }
}
